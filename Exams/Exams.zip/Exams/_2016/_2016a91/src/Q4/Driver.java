package Q4;
/**
 * Written by Koren Ben Ezra
 * In 2022b
 */
public class Driver {

    public static void main(String[] args) {

        // 1
//        A a = new B();
//        a.set();
//        System.out.println(a.get());

        // 2
//        System.out.println(a.get(4));

        // 3
//        A a = new B(99);
//        a.set();
//        System.out.println(a.get());

        // 4
//        B b = new B();
//        b.f2(b);

        // 5
//        B b = new B();
//        A a = b;
//        b.f1(a);

        // 6
//        B b = new B();
//        ((A)b).f2(b);

        // 7
//        B b = new B();
//        A a = new C();
//        a = b;
//        ((C) a).f2(a);


        // 8
//        C c = new C();
//        c.f3(c);

        // 9
//        C c = new C();
//        c.f3((A)c);

        // 10
//        C c = new C();
//        ((A)c).f3((A)c);

        // 11
//        A a = new C();
//        a.f3(a);

        // 12
//        A a = new C();
//        ((C) a).f3(a);

    }

}
