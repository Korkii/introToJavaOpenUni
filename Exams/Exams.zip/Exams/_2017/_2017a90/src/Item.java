public class Item {
    private int _weight;
    private int _value;

    public Item(int w, int v){
        _weight = w;
        _value = v;
    }

    public int getWeight(){
        return _weight;
    }
    public int getValue(){
        return _value;
    }

}
