public class Range {

    private int _center, _radius;

    public Range(int c, int r){
        _center = c;
        _radius = r;
    }

    public int getCenter(){
        return _center;
    }

    public int get_radius(){
        return _radius;
    }

}
