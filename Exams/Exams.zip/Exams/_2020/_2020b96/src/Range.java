public class Range {
    private int _small, _big;

    public Range(int s, int b) {
        _small = s;
        _big = b;
    }

    public int getSmall() {
        return _small;
    }

    public int getBig() {
        return _big;
    }
}