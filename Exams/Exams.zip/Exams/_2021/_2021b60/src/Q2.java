/**
 * Written by Koren Ben Ezra
 * In 2022b
 */
public class Q2 {

    // Time complexity: O(n)
    // Space complexity: O(1)
    public static int smallestSub(int[] a, int k){

        int tempSum = 0,low = 0, high = a.length-1;

        for (int i = 0; i < a.length; i++) {
            tempSum += a[i];
        }

        if(tempSum <= k)
            return a.length + 1;

        while (low < high){

            if(a[low] < a[high]){
                tempSum -= a[low];
                low++;
            }
            else{
                tempSum -= a[high];
                high--;
            }

            if(tempSum <= k)
                return (high - low + 2);
        }
        // low == high --> there is one element that is greater than k.
        // therefore, there is sub-series within length 1 that the sum of it is greater than k.
        return 1;
    }


    public static void main(String[] args){

        int[] arr = {1,4,13,6,0,19};
        int smallestSize = smallestSub(arr, 22);
        System.out.println("expected 3: " + smallestSize);

        smallestSize = smallestSub(arr, 42);
        System.out.println("expected 6: " + smallestSize);

        smallestSize = smallestSub(arr, 43);
        System.out.println("expected 7: " + smallestSize);

        smallestSize = smallestSub(arr, 26);
        System.out.println("expected 4: " + smallestSize);

        smallestSize = smallestSub(arr, 2);
        System.out.println("expected 1: " + smallestSize);
    }
}
